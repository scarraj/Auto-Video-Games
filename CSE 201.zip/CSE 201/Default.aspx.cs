﻿using _385WebExample;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CSE_201
{
    public partial class _Default : Page
    {

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            api ws = new api();
            StringBuilder sb = new StringBuilder();

            ws.addParam("@name", gameName.Text);
            DataTable tbl = ws.sqlExecDataTable("getGameByName");

            foreach (DataRow row in tbl.Rows)
                sb.Append("<div class='alert alert-success'>" + 
                          "Game: " + row["name"] + "</br>" + 
                          "Genre: " + row["genre"] + "</br>" +
                          "Price: $" + row["price"] + "</br>" +
                          "Platforms: " + row["platforms"] + "</br>" +
                          "Release Date: " + row["releaseDate"] +"</div>"); 
            searchLabel.Text = sb.ToString();
        }
    }
}