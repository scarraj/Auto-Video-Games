﻿using System.Web.UI;

namespace CSE_201.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}